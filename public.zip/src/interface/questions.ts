export default interface IQuestions {
    question: string,
    answer: number
}