export default function Header(){
    return (
        <header className="bg-gray-800 text-white p-4 text-center header">
        <h1>Avaliação de Gestão Financeira na Escola</h1>
        </header>
    );
}